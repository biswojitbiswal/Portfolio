/*===============MENU SHOW Y HIDDEN=================*/
const navMenu=document.querySelector('.nav-menu'),
    navToggle=document.querySelector('#nav-toggle'),
    navlCose=document.querySelector('#nav-close');

/*===============MENU SHOW=================*/
    navToggle.addEventListener('click', () =>{
        alert("toggled");
                navMenu.classList.add('show-menu');
    })